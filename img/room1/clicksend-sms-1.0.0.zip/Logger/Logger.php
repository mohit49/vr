<?php
namespace Clicksend\Sms\Logger;

class Logger extends \Monolog\Logger
{
    
}
